"use client"

import { DesignerPortal } from "../components/designer-portal"

export default function SyntheticV0PageForDeployment() {
  return <DesignerPortal />
}